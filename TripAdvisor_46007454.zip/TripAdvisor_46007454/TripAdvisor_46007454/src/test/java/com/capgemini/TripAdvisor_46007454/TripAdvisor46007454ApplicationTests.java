package com.capgemini.TripAdvisor_46007454;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripAdvisor46007454ApplicationTests {

	@Test
	void contextLoads() {
	}

}
