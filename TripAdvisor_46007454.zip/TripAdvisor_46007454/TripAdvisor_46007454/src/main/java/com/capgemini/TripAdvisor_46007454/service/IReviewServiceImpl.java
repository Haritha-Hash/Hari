package com.capgemini.TripAdvisor_46007454.service;

import java.util.List;
import java.util.Optional;

import com.capgemini.TripAdvisor_46007454.exception.ReviewsException;
import com.capgemini.TripAdvisor_46007454.review.Reviews;

public interface IReviewServiceImpl {

	
	  public void createReview(Reviews reviews) throws ReviewsException;
	  public void updateReview(String name,Reviews reviews) throws ReviewsException;
	  public void deleteReview(String id);
	  public List<Reviews> viewAllReviews();
	  public Optional<Reviews> findSingleReview(String id);
  
}
