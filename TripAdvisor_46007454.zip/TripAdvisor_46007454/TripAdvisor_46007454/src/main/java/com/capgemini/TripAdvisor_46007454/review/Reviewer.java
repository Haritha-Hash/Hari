package com.capgemini.TripAdvisor_46007454.review;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;



@Entity
public class Reviewer {
	@Id
	private String reviewer_id;
	private String name;
	private String email;
	
	@OneToMany(targetEntity=Reviews.class,fetch=FetchType.LAZY,mappedBy="reviewer")
	private List<Reviews> reviewslist = new ArrayList<>();
	
	public Reviewer() {
		super();
	}
	public Reviewer(String reviewer_id, String name, String email) {
		super();
		this.reviewer_id = reviewer_id;
		this.name = name;
		this.email = email;
	}
	public String getReviewer_id() {
		return reviewer_id;
	}
	public void setReviewer_id(String reviewer_id) {
		this.reviewer_id = reviewer_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Reviewer [reviewer_id=" + reviewer_id + ", name=" + name + ", email=" + email + "]";
	}
	
}
