package com.capgemini.TripAdvisor_46007454.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.TripAdvisor_46007454.exception.ReviewsException;
import com.capgemini.TripAdvisor_46007454.review.Reviews;
import com.capgemini.TripAdvisor_46007454.service.IReviewServiceImpl;
import com.capgemini.TripAdvisor_46007454.service.ReviewsService;




@RestController
public class ReviewsController {

	@Autowired
	private IReviewServiceImpl reviewservice;
	
	
	@GetMapping("/reviews")
	public List<Reviews> viewAllReviewsController()
	{
	   return reviewservice.viewAllReviews();
	}

	@GetMapping("/reviews/{id}")
	public Optional<Reviews> findSingleReviewController(@PathVariable String id)
	{
	  return reviewservice.findSingleReview(id);
	}
	
	@PostMapping("/reviews")
	public void addReviewController(@RequestBody Reviews reviews) throws ReviewsException
	{
		reviewservice.createReview(reviews);
	}
	
	
	@PutMapping("/reviews/{name}")
	  public void updateReviewsController(@PathVariable String name,@RequestBody Reviews reviews ) throws ReviewsException
	    {
		reviewservice.updateReview(name, reviews);
	    }
	
	@DeleteMapping("/reviews/{id}")
	public void deleteReviewController(@PathVariable String id )
	{
		reviewservice.deleteReview(id);
	}
	
	
}
