package com.capgemini.TripAdvisor_46007454;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripAdvisor46007454Application {

	public static void main(String[] args) {
		SpringApplication.run(TripAdvisor46007454Application.class, args);
	}

}
