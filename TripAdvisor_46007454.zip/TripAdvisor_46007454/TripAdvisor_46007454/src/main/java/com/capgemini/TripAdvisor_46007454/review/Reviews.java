package com.capgemini.TripAdvisor_46007454.review;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Reviews {
	@Id
	private String review_id;
	private String description;
	private int rating;
	
	@ManyToOne
	private Reviewer reviewer;
	public Reviews() {
		super();
	}
	public Reviews(String review_id, String description, int rating) {
		super();
		this.review_id = review_id;
		this.description = description;
		this.rating = rating;
	}
	public String getReview_id() {
		return review_id;
	}
	public void setReview_id(String review_id) {
		this.review_id = review_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public Reviewer getReviewer() {
		return reviewer;
	}
	public void setReviewer(Reviewer reviewer) {
		this.reviewer = reviewer;
	}
	@Override
	public String toString() {
		return "Reviews [review_id=" + review_id + ", description=" + description + ", rating=" + rating + ", reviewer="
				+ reviewer + "]";
	}
	
}
