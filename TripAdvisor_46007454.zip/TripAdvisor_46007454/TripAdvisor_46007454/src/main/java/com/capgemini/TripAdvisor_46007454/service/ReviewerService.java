package com.capgemini.TripAdvisor_46007454.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.TripAdvisor_46007454.DAO.IReviewerRepo;
import com.capgemini.TripAdvisor_46007454.review.Reviewer;


	@Service
	public class ReviewerService implements IReviewerServiceImpl {

		@Autowired
		private IReviewerRepo reviewerrepository;
		
		
		@Override
		public List<Reviewer> viewAllReviewer() {
			// TODO Auto-generated method stub
			  List<Reviewer> reviewerlist = new ArrayList<>();  
		      reviewerrepository .findAll().forEach(reviewerlist::add);  
		      return reviewerlist;  
		}

		@Override
		public Reviewer getSingleReviewer(String id) {
			// TODO Auto-generated method stub
			 List<Reviewer> reviewerlist = new ArrayList<>(); 
			  reviewerlist=(List<Reviewer>) reviewerrepository.findAll();
			  for(Reviewer r:reviewerlist)
			  {
				  if(r.getReviewer_id().equals(id))
				  {
					  return r;
				  }
			  }
			return null;
		}
		
		@Override
		public void addReviewer(Reviewer reviewer) {
			// TODO Auto-generated method stub
			reviewerrepository.save(reviewer);
		}

	}


