package com.capgemini.TripAdvisor_46007454.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.TripAdvisor_46007454.DAO.IReviewsRepo;
import com.capgemini.TripAdvisor_46007454.exception.ReviewsException;
import com.capgemini.TripAdvisor_46007454.review.Reviewer;
import com.capgemini.TripAdvisor_46007454.review.Reviews;


	
	@Service
	public class ReviewsService implements IReviewServiceImpl {
		
		@Autowired
		private ReviewerService reviewerservice;
		
		@Autowired
		private IReviewsRepo reviewsrepository;
		

		@Override
		public void createReview(Reviews reviews)  throws ReviewsException {
			// TODO Auto-generated method stub
			 if(!reviewsrepository.existsById(reviews.getReview_id()))
             {
         throw new ReviewsException("Review Id with " + reviews.getReview_id() + " Does not Exist");
     }
     reviewsrepository.save(reviews);
 } 
		
		
		
		

		@Override
		public void updateReview(String name, Reviews reviews) {
			// TODO Auto-generated method stub
			reviewsrepository.save(reviews);
		}

		@Override
		public void deleteReview(String id) {
			// TODO Auto-generated method stub
			reviewsrepository.deleteById(id);
		}

		@Override
		public List<Reviews> viewAllReviews() {
			// TODO Auto-generated method stub
			 List<Reviews> reviewlist = new ArrayList<>();  
		     reviewsrepository .findAll().forEach(reviewlist::add);  
		     return reviewlist;  
		}

		@Override
		public Optional<Reviews> findSingleReview(String id) {
			// TODO Auto-generated method stub
			  return reviewsrepository.findById(id);  
		}
		
	}

