package com.capgemini.TripAdvisor_46007454.DAO;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.TripAdvisor_46007454.review.Reviews;

public interface IReviewsRepo extends CrudRepository<Reviews, String> {

}
