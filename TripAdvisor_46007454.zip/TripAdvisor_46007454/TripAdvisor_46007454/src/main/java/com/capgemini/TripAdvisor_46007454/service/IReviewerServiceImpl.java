package com.capgemini.TripAdvisor_46007454.service;

import java.util.List;

import com.capgemini.TripAdvisor_46007454.review.Reviewer;

public interface IReviewerServiceImpl {

	public List<Reviewer> viewAllReviewer();
	public Reviewer getSingleReviewer(String id);
    public void addReviewer(Reviewer reviewer);
}