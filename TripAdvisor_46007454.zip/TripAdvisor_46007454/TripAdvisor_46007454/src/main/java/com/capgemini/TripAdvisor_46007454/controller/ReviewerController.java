package com.capgemini.TripAdvisor_46007454.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.TripAdvisor_46007454.review.Reviewer;
import com.capgemini.TripAdvisor_46007454.service.IReviewerServiceImpl;
import com.capgemini.TripAdvisor_46007454.service.ReviewerService;

@RestController
public class ReviewerController {

	@Autowired
	private IReviewerServiceImpl reviewerservice;
	

	@GetMapping("/reviewer")
	public List<Reviewer> viewAllReviewerController()
	{
	   return reviewerservice.viewAllReviewer();
	}
	@PostMapping("/reviewer")
	public void addReviewer(@RequestBody Reviewer r)
	{
		reviewerservice.addReviewer(r);
	}
	
}
