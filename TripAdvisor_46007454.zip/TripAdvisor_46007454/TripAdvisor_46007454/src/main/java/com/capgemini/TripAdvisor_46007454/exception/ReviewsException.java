package com.capgemini.TripAdvisor_46007454.exception;


//Exception Class
public class ReviewsException extends Exception {

	//userdefined Exception Reviews Exception
    public ReviewsException() {
        super();
    }
    public ReviewsException(String message) {
        super(message);
    }
}
