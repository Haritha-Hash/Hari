import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
 
@Injectable({
  providedIn: 'root'
})
export class MobileService {

   
 constructor(private http:HttpClient) { }
 add(mobile){
 let opt = new HttpHeaders({'Content-Type':'application/json'})
 return this.http.post('http://localhost:3000/Mobile',mobile,{headers:opt})
 }
 getAll(){
 return this.http.get('http://localhost:3000/Mobile')
 }
 remove(mid){
 return this.http.delete('http://localhost:3000/Mobile/'+mid)
 }
}
