package com.cg.retailstore.bean;

public class CustomertDetails {
      
public CustomertDetails(String customerName, int purchaseAmount) {
		
		this.customerName = customerName;
		this.purchaseAmount = purchaseAmount;
	}
	private String customerName;
      private int purchaseAmount;
      
      
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getPurchaseAmount() {
		return purchaseAmount;
	}
	public void setPurchaseAmount(int purchaseAmount) {
		this.purchaseAmount = purchaseAmount;
	}
	@Override
	public String toString() {
		return "CustomertDetails [customerName=" + customerName + ", purchaseAmount=" + purchaseAmount + "]";
	}
}
