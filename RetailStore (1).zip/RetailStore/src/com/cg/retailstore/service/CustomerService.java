package com.cg.retailstore.service;

public class CustomerService implements ICustomerService {

	@Override
	public double discountCalculation(double amount, int choice) {
		
		double discount=0;
		switch(choice) {
		
		case 1:
		    discount= (amount*30)/100;
		    discount=amount-discount;
		 	break;
		case 2:
			 discount= (amount*10)/100;
			 discount=amount-discount;
			 break;
		case 3:
		     discount= (amount*30)/100;
		     discount=amount-discount;
			 break;
		case 4:
	         discount= (amount/100)*5;
	         discount=amount-discount;
		     break;
		case 5:
			discount=amount;
			
		}
		
		return discount;
	}

}
