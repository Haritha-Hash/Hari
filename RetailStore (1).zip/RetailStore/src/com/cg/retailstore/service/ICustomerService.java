package com.cg.retailstore.service;

public interface ICustomerService {
	public double discountCalculation(double amount, int choice);
}
