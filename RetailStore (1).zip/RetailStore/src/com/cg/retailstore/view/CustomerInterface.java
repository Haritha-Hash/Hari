package com.cg.retailstore.view;

import java.util.Scanner;

import com.cg.retailstore.dao.CustomerDao;
import com.cg.retailstore.dao.ICustomer;
import com.cg.retailstore.service.CustomerService;
import com.cg.retailstore.service.ICustomerService;

public class CustomerInterface {
	public static void main(String args[])
	{
		System.out.println("Enter Your Name");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		System.out.println("Enter the Amount");
		double amount=sc.nextInt();
				System.out.println("Are You Applicable for?\n 1.Employee of the Store Discount \n "
				+ "2.Affiliate of the Store Discount\n 3.Customer for more than 2 Years Discount\n 4. Applicable for none of the above \n 5.If you bought Grocery");
		
		int choice=sc.nextInt();
		ICustomerService customerservice=new CustomerService(); {
		};
		System.out.println("Amount To Be Paid :"+ customerservice.discountCalculation(amount,choice));
		
		}

}
