package com.cg.retailstore.dao;

public class CustomerDao implements ICustomer {

	
	

	
}
