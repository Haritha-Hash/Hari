package com.cg.retailstore.dao;

public interface ICustomer {

	
}
