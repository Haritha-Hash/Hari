import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {


  products;
  constructor(private ps: ProductService) {
    
   }

   getAllProducts(){
     this. ps.getAll().subscribe((res)=>this.products=res)
   }
  ngOnInit() {
  }

}