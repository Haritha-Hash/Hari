/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is main class
 */
package com.cg.phonepay.ui;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;

import com.cg.phonepay.bean.CreateAccount;
import com.cg.phonepay.service.BankService;
import com.cg.phonepay.service.IBankService;

public class Main {

	public static void main(String[] args) {
		List<CreateAccount> list = new ArrayList<>();
		ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<>(100);
		CreateAccount create = null;
		String custname, transactions = null;
		String city;
		String phonenum;
		BankService bankservice = new BankService();
		System.out.println("WELCOME");
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("Select one of the options:");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			int choice = 0;
			int balance = 0;
			choice = scanner.nextInt();
			int accountno;

			switch (choice) {

			case 1:

				create = new CreateAccount();
				accountno = (int) (1000 * Math.random());
				create.setAccountno(accountno);
				System.out.println("Enter your name:");
				custname = scanner.next();
				create.setCustname(custname);
				System.out.println("Enter your city:");
				city = scanner.next();
				create.setCity(city);
				System.out.println("Enter your phonenum:");
				phonenum = scanner.next();
				create.setPhoneNum(phonenum);
				list.addAll(bankservice.addAccount(create));
				System.out.println("Successfully created your account:");
				System.out.println("Your account number is:" + accountno);

				break;
			case 2:
				System.out.println("Enter the account number:");
				int num = scanner.nextInt();
			
				System.out.println(bankservice.viewDetails(num, list));

				break;
			case 3:
				System.out.println("Enter the account number:");
				int acnum1 = scanner.nextInt();
				System.out.println("Enter the amount to be deposited:");
				long amount = scanner.nextLong();
				System.out.println("Your available balance is:" + bankservice.deposit(acnum1, amount, list));
				queue.addAll(bankservice.transactions("/n"));
				break;
			case 4:
				System.out.println("Enter the account number:");
				int acnum2 = scanner.nextInt();
				System.out.println("Enter the amount to be withdrawn:");
				long amount1 = scanner.nextLong();
				System.out.println("Your available balance is:" + bankservice.withdraw(acnum2, amount1, list));
				queue.addAll(bankservice.transactions("/n"));
				break;
			case 5:
				System.out.println("Enter your account number:");
				int acnum = scanner.nextInt();
				System.out.println("Enter reciepient account number:");
				int numRecp = scanner.nextInt();
				System.out.println("Enter the amount to be transferred:");
				long amt = scanner.nextLong();
				System.out.println("Your available balance is:" + bankservice.fundTransfer(acnum, numRecp, amt, list));
				queue.addAll(bankservice.transactions("/n"));
				break;
			case 6:
				Set<String> str = new LinkedHashSet<>();
				str.addAll(queue);
				System.out.println(str);
				break;
			case 7:
				System.out.println("Thank you! for using our service.");
				break;
			default:
				System.out.println("Enter valid option");
				break;
			}
		}
	}
}
