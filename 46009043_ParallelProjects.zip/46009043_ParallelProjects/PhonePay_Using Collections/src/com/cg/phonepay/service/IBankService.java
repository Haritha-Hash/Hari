/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is the interface of service  class
 */
package com.cg.phonepay.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.phonepay.bean.CreateAccount;

public interface IBankService {
	public List<CreateAccount> addAccount(CreateAccount create);

	public long deposit(int accountnum1, long bal1, java.util.List<CreateAccount> list);

	public long withdraw(int accountnum1, long bal1, java.util.List<CreateAccount> list);

	long viewDetails(int accountnum1, List<CreateAccount> list);

	long fundTransfer(int accountnum1, int accountnum2, long amt, List<CreateAccount> list);
}
