/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is service class
 */
package com.cg.phonepay.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.phonepay.bean.CreateAccount;
import com.cg.phonepay.dao.BankDao;
import com.cg.phonepay.exception.InvalidAccountNumber;
import com.cg.phonepay.exception.InvalidMobileNumberException;

public class BankService implements IBankService {
	BankDao bankDao = new BankDao();

	@Override
	public List<CreateAccount> addAccount(CreateAccount create) {
		BankDao Idao = null;
		Idao = new BankDao();
		validateMobileNumber(create.getPhoneNum());
		return Idao.addAccount(create);

	}

	private void validateMobileNumber(String cell) {
		Pattern pattern = Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher idMatcher = pattern.matcher(cell);

		if (!idMatcher.matches())
			try {
				throw new InvalidMobileNumberException();
			} catch (InvalidMobileNumberException e) {

				e.printStackTrace();
			}
	}

	@Override
	public long viewDetails(int s, List<CreateAccount> list) {
		try {
			if (!validateAccountNumber(s, list)) {
				throw new InvalidAccountNumber();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return  bankDao .viewDetails(s, list);

	}

	@Override
	public long deposit(int i, long s, List<CreateAccount> l) {

		try {
			if (!validateAccountNumber(i, l)) {
				throw new InvalidAccountNumber();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return  bankDao .deposit(i, s, l);

	}

	private boolean validateAccountNumber(int i, List<CreateAccount> l) {
		Iterator<CreateAccount> itr = l.iterator();
		while (itr.hasNext()) {
			CreateAccount acc = itr.next();
			if (acc.getAccountno() == i)
				return true;
		}
		return false;
	}

	@Override
	public long withdraw(int i, long s, List<CreateAccount> l) {
		try {
			if (!validateAccountNumber(i, l)) {
				throw new InvalidAccountNumber();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return  bankDao .withdraw(i, s, l);

	}

	@Override
	public long fundTransfer(int s, int b, long amt, List<CreateAccount> l) {
		try {
			if (!validateAccountNumber(s, l)) {
				throw new InvalidAccountNumber();
			}
			if (!validateAccountNumber(b, l)) {
				throw new InvalidAccountNumber();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return  bankDao .fundTransfer(s, b, amt, l);
	}

	public ArrayList<String> transactions(String s) {
		ArrayList<String> transaction = new ArrayList<>();
		transaction.addAll( bankDao .transactions(" "));
		return transaction;
	}
}
