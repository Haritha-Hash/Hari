/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is interface of ACCOUNT class
 */
package com.cg.phonepay.bean;

import java.util.concurrent.ArrayBlockingQueue;

public class CreateAccount {
	private int accountNo;
	private String custName;
	private String city;
	private String phoneNum;
	private long balance = 0;

	public CreateAccount() {
		super();

	}

	public CreateAccount(int accountNo, String custname, String city, String cellnumber, long balance) {
		super();
		this.accountNo = accountNo;
		this.custName = custname;
		this.city = city;
		this.phoneNum = phoneNum;
		this.balance = balance;
	}

	public int getAccountno() {
		return accountNo;
	}

	public void setAccountno(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getCustname() {
		return custName;
	}

	public void setCustname(String custname) {
		this.custName = custName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "CreateAccount [accountNo=" + accountNo + ", custName=" + custName + ", city=" + city + ", phoneNum="
				+ phoneNum + ", balance=" + balance + "]";
	}

}
