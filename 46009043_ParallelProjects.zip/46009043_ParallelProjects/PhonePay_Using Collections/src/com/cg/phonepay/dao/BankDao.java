/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is DAO class
 */
package com.cg.phonepay.dao;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import com.cg.phonepay.bean.CreateAccount;
import com.cg.phonepay.service.BankService;
import com.cg.phonepay.util.BankCollections;

public class BankDao implements IBankDao {

	BankCollections bankCollections = new BankCollections();

	public List<CreateAccount> addAccount(CreateAccount create) {

		return bankCollections.add(create);

	}

	public long viewDetails(int s, List<CreateAccount> list) {

		return bankCollections.balance(s, list);
	}

	public long deposit(int i, long s, List<CreateAccount> list) {

		return bankCollections.deposit(i, s, list);

	}

	public long withdraw(int i, long s, List<CreateAccount> list) {

		return bankCollections.withdraw(i, s, list);

	}

	public long fundTransfer(int s, int b, long amt, List<CreateAccount> list) {

		return bankCollections.fundTransfer(s, b, amt, list);
	}

	public ArrayList<String> transactions(String s) {
		ArrayList<String> transaction = new ArrayList<>();
		transaction.addAll(bankCollections.transactions(""));
		return transaction;
	}

}
