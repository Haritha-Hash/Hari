/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is bank collection  class
 */
package com.cg.phonepay.util;

import java.awt.List;

import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.phonepay.bean.CreateAccount;
import com.cg.phonepay.dao.BankDao;
import com.cg.phonepay.exception.AmountException;

public class BankCollections {
	Scanner scanner = new Scanner(System.in);
	ArrayList<CreateAccount> list = new ArrayList<>();
	CreateAccount account;
	ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<>(10);

	public java.util.List<CreateAccount> add(CreateAccount create) {
		list.add(create);
		return list;
	}

	public long balance(int d, java.util.List<CreateAccount> list) {
		long b = 0;
		Iterator<CreateAccount> iterator = list.iterator();

		while (iterator.hasNext()) {
			CreateAccount create = iterator.next();
			if (d == create.getAccountno()) {
				b = create.getBalance();
			}
		}
		return b;
	}

	public long deposit(int acntno, long damount, java.util.List<CreateAccount> list) {
		Iterator<CreateAccount> iterator = list.iterator();

		while (iterator.hasNext()) {
			CreateAccount create = iterator.next();
			if (acntno == create.getAccountno()) {
				create.setBalance(create.getBalance() + damount);
				damount = create.getBalance();
			}
		}
		transactions("you deposited amount " + damount + " to your account with account number " + acntno + "\n");
		return damount;
	}

	public long withdraw(int acntno, long drawn, java.util.List<CreateAccount> list) {
		Iterator<CreateAccount> iterator = list.iterator();

		try {

			while (iterator.hasNext()) {
				CreateAccount create = iterator.next();
				if (acntno == create.getAccountno()) {
					if (create.getBalance() > drawn) {
						create.setBalance(create.getBalance() - drawn);
						drawn = create.getBalance();
					} else
						throw new AmountException();
				}
			}
			transactions("you withdrew amount " + drawn + " to your account with account number " + acntno + "\n");
			return drawn;

		} catch (Exception e) {
			System.out.println(e);
		}
		return drawn;
	}

	public long fundTransfer(int acntno, int drawn, long amnt, java.util.List<CreateAccount> list) {
		Iterator<CreateAccount> iterator = list.iterator();
		long account1 = 0, account2 = 0;
		while (iterator.hasNext()) {

			CreateAccount create = iterator.next();
			try {
				if (acntno == create.getAccountno()) {
					if (create.getBalance() > amnt) {
						create.setBalance(create.getBalance() - amnt);
						account1 = create.getBalance();
					} else
						throw new AmountException();
				}
				if (drawn == create.getAccountno()) {
					create.setBalance(create.getBalance());
					account2 = create.getBalance();
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		transactions("you transferred amount: " + amnt + " from your account with account number " + acntno
				+ " to account number " + drawn + "\n");
		return account1;

	}

	public ArrayBlockingQueue<String> transactions(String str) {
		queue.add(str);

		return queue;

	}

}
