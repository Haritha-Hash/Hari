package com.cg.phonepay.test;

import static org.junit.Assert.*;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import java.util.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.phonepay.bean.CreateAccount;
import com.cg.phonepay.service.BankService;

public class BankServiceTest {
	CreateAccount name1, name2;
	List<CreateAccount> list = new ArrayList<>();
	BankService service = new BankService();
	Iterator<CreateAccount> itr;
	long bal = 0;

	@Before
	public void setUp() throws Exception {
		name1 = new CreateAccount(1, "Hari", "hyderabad", "8142602479", 100000);
		name2 = new CreateAccount(10, "Roy", "hyderabad", "9733956468", 10000);
		list.addAll(service.addAccount(name1));
		list.addAll(service.addAccount(name2));
	}

	@After
	public void tearDown() throws Exception {

	}

	@Test
	public void testAddAccount() {
		
	}

	@Test
	public void testViewDetails() {
		bal = service.viewDetails(1, list);
		assertEquals(100000, bal);
	}

	@Test
	public void testDeposit() {
		bal = service.deposit(1, 2000, list);
		// itr=li.iterator();
		assertEquals(2000, bal);
	}

	@Test
	public void testWithdraw() {
		System.out.println(list);
		bal = service.withdraw(1, 20000, list);
		assertEquals(80000, bal);
	}

	@Test
	public void testFundTransfer() {
		bal = service.fundTransfer(1, 10, 20000, list);
		assertEquals(80000, bal);
	}

}
