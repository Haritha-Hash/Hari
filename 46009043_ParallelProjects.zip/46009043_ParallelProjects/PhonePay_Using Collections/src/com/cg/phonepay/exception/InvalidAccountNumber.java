/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is invalid account number exception class
 */
package com.cg.phonepay.exception;

public class InvalidAccountNumber extends Exception {

	public InvalidAccountNumber() {
		super();

	}

	@Override
	public String toString() {
		return "InvalidAccountNumber";
	}

}
