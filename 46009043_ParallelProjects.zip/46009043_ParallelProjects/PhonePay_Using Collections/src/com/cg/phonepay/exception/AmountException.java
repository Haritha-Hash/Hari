/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is invalid amount exception class
 */
package com.cg.phonepay.exception;

public class AmountException extends Exception {

	public AmountException() {
		super();

	}

	@Override
	public String toString() {
		return "Insufficient balance!!";
	}

}
