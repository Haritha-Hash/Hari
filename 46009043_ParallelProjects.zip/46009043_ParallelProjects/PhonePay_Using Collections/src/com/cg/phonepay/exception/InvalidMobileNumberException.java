/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is invalid mobile number exception class
 */
package com.cg.phonepay.exception;

public class InvalidMobileNumberException extends Exception {

	public InvalidMobileNumberException() {
		super();

	}

	@Override
	public String toString() {
		return "InvalidMobileNumberException";
	}

}
