package com.cg.BankAppBoot.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cg.BankAppBoot.bean.*;

@Repository
public interface BankDao extends JpaRepository<Bank,Integer>
{
	
}
