package com.cg.BankAppBoot.bean;


import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="banking_details")
public class Bank 
{
	@Id
	@GeneratedValue
private int accountId;
//@Pattern(regexp="[A-Z][a-z]*")
private String username;
private double balance;
//@Pattern(regexp="(91)||(91 )?[6-9][0-9]{9}")
private String phoneNumber;
private String password;

/*@JsonFormat(with=JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
@OneToMany(cascade = CascadeType.ALL)
private List<Transaction> transaction=new ArrayList<>();*/


/*public List<Transaction> getTransaction() {
	return transaction;
}
public void setTransaction(List<Transaction> transaction) {
	this.transaction = transaction;
}*/
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}

public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public double getBalance() {
	return balance;
}
public void setBalance(double d) {
	this.balance = d;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
}