package com.cg.BankAppBoot.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.BankAppBoot.bean.*;



public interface TransactionDao extends JpaRepository <Transaction,Long> 
{
	@Query("from Transaction where AccountNumber = :accn")
	List<Transaction> findById(@Param("accn") long acc);

	static List<Transaction> printTransaction(long accno) {
		
		return null;
	}
}