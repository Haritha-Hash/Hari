/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is the class with main method where execution starts
 */
package com.cg.gpay.view;

import java.util.Scanner;
import com.cg.gpay.service.CustomerController;
import com.cg.gpay.service.ICustomerController;

public class MainBank {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		ICustomerController custintf = new CustomerController();
		while (true) {
			System.out.println("welcome to CITIBANK, Please choose the option");
			System.out.println("1 CreateAccount");
			System.out.println("2 ShowBalance");
			System.out.println("3 Deposit");
			System.out.println("4 WithDraw");
			System.out.println("5 TranferFunds");
			System.out.println("6 printTransaction");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				custintf.addCust();
				break;
			case 2:
				System.out.println("please enter your accountid");
				int acntid = sc.nextInt();
				System.out.println("Your account balance is : " + custintf.viewBalance(acntid));
				break;
			case 3:
				custintf.deposit();
				break;
			case 4:
				custintf.withdraw();
				break;
			case 5:
				custintf.transferfunds();
				break;
			case 6:
				int aid = 0;
				int amnt = 0;
				int actid = 0;
				String s = null;
				custintf.printDetails(aid, actid, amnt, s);

				break;
			default:
				System.out.println("please enter valid input");
				break;

			}

		}

	}
}
