/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is DAO class
 */
package com.cg.gpay.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.cg.gpay.helper.DBConnection;
import com.cg.gpay.helper.QueryMapper;
import com.cg.gpay.model.Account;
import com.cg.gpay.model.Customer;
import com.cg.gpay.model.Transaction;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAOClass implements IDAOClass {
	private Connection conn;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	double k;

	public int create(Account account) {
		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn.prepareStatement("insert into account values(?,?,?,?,?,?)");
			preparedStatement.setDouble(1, account.getAccountId());
			preparedStatement.setString(2, account.getAccountType());
			preparedStatement.setDouble(3, account.getBalance());
			preparedStatement.setString(4, account.getCustName());
			preparedStatement.setString(5, account.getPhoneNo());
			preparedStatement.setString(6, account.getCity());

			int k = preparedStatement.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		}
		System.out.println("data inserted");
		return 0;
	}

	public double update(int acntid, double balance) {
		conn = DBConnection.getConnection();
		Account ac = new Account();
		double l = 0;
		try {
			preparedStatement = conn
					.prepareStatement("update account set balance=" + balance + "where accountId=" + acntid);
			l = preparedStatement.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		}
		System.out.println("balance updated");
		return l;
	}

	public double viewBalance(int acntid) {
		conn = DBConnection.getConnection();

		try {
			preparedStatement = conn
					.prepareStatement("select BALANCE from ACCOUNT where accountid=" + "'" + acntid + "'");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				k = resultSet.getDouble("BALANCE");
			}
		} catch (SQLException se) {

			se.printStackTrace();
		}
		return k;
	}

	public void printDetails(int aid, int aaid, int amnt, String s) {
		ArrayList<Transaction> list = new ArrayList<>();
		try {
			conn = DBConnection.getConnection();
			preparedStatement = conn.prepareStatement("insert into printdetails values(?,?,?,?)");
			preparedStatement.setInt(1, aid);
			preparedStatement.setInt(2, aaid);
			preparedStatement.setInt(3, amnt);
			preparedStatement.setString(4, s);
			int k = preparedStatement.executeUpdate();
			System.out.println("data captured");
			preparedStatement = conn.prepareStatement("select * from printdetails");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Transaction transaction = new Transaction();
				transaction.setAccountId2(resultSet.getInt(1));
				transaction.setAccountId(resultSet.getInt(2));
				transaction.setAmount(resultSet.getInt(3));
				transaction.setMessage(resultSet.getString(4));
				list.add(transaction);
			}
		} catch (SQLException se) {

			se.printStackTrace();
		}
	}

	public ArrayList<Transaction> viewDetails() {
		ArrayList<Transaction> list = new ArrayList<Transaction>();
		conn = DBConnection.getConnection();
		try {
			preparedStatement = conn.prepareStatement("select * from printdetails");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Transaction transaction = new Transaction();
				transaction.setAccountId2(resultSet.getInt(1));
				transaction.setAccountId(resultSet.getInt(2));
				transaction.setAmount(resultSet.getInt(3));
				transaction.setMessage(resultSet.getString(4));
				list.add(transaction);
			}
		} catch (SQLException se) {

			se.printStackTrace();
		}
		return list;

	}

	@Override
	public void addCust() {

	}

	@Override
	public void deposit() {

	}

	@Override
	public void withdraw() {

	}

	@Override
	public void transferfunds() {

	}
}
