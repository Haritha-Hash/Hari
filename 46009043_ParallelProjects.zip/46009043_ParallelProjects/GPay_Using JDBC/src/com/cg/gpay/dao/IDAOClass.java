/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is interface of DAO class
 */
package com.cg.gpay.dao;

import java.util.ArrayList;

import com.cg.gpay.model.Account;
import com.cg.gpay.model.Customer;
import com.cg.gpay.model.Transaction;

public interface IDAOClass {

	int create(Account account);

	public void addCust();

	double update(int acntid, double balance);

	public void deposit();

	public void withdraw();

	public void transferfunds();

	void printDetails(int aid, int acntid, int amnt, String s);

	public ArrayList<Transaction> viewDetails();

	public double viewBalance(int acntid);
}
