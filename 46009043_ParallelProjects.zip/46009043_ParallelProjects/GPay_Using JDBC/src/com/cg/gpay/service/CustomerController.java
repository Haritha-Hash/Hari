/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is customer controller class in which logics are implemented
 */
package com.cg.gpay.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.gpay.dao.*;
import com.cg.gpay.model.*;

public class CustomerController implements ICustomerController {
	Customer cust;
	IDAOClass daoI;
	Account accnt;
	double updatedbal;
	// deposit money
	Scanner obj = new Scanner(System.in);
	String regex = "(0/91)?[7-9][0-9]{9}";
	String sav = "savings";
	String cur = "current";

	public void addCust() {
		System.out.println("enter account type");
		String acntType = obj.next();
		while (!acntType.equals(sav) && (!acntType.equals(cur))) {
			System.out.println("Invalid type account,please enter valid account Type");
			acntType = obj.next();
		}
		System.out.println("Enter customer Name");
		String cname = obj.next();
		System.out.println("Enter phone number");
		String phoneno = obj.next();
		System.out.println("Enter city name");
		String city = obj.next();
		int actno = (int) (Math.random() * 1000000000);
		while (!phoneno.matches(regex)) {
			System.out.println("Invalid phoneno, please enter valid phonenumber");
			phoneno = obj.next();
		}
		System.out.println("Your accountNo is : " + actno);
		System.out.println("enter amount");
		double bal1 = obj.nextDouble();
		accnt = new Account();
		accnt.setAccountId(actno);
		accnt.setAccountType(acntType);
		accnt.setCustName(cname);
		accnt.setPhoneNo(phoneno);
		accnt.setBalance(bal1);

		List<Account> custlist = new ArrayList<>();
		custlist.add(accnt);
		daoI = new DAOClass();
		daoI.create(accnt);
	}

	// deposit money
	public void deposit() {
		daoI = new DAOClass();
		System.out.println("Enter accountId");
		int aid = obj.nextInt();
		System.out.println("Enter amount to deposit");
		int amnt = obj.nextInt();
		accnt = new Account();
		updatedbal = accnt.getAmount(amnt, daoI.viewBalance(aid));
		accnt.setBalance(updatedbal);
		daoI.update(aid, updatedbal);
		System.out.println("balance updated");
		String s = "deposited";
		daoI.printDetails(aid, aid, amnt, s);

	}

	// withdraw money
	public void withdraw() {
		daoI = new DAOClass();
		System.out.println("enter accountId");
		int aid = obj.nextInt();
		System.out.println("enter amount to withdraw");
		int amnt = obj.nextInt();
		accnt = new Account();
		double bal2 = daoI.viewBalance(aid);
		if (amnt < bal2) {
			updatedbal = accnt.withdraw(bal2, amnt);
		} else {
			System.out.println("invalid amount");
		}
		accnt.setBalance(updatedbal);
		daoI.update(aid, updatedbal);
		System.out.println("balance withdrawn");
		String s = "withdrawn";
		daoI.printDetails(aid, aid, amnt, s);
	}

	// transfer amount
	public void transferfunds() {
		daoI = new DAOClass();
		System.out.println("Enter your accountId");
		int acnum = obj.nextInt();
		System.out.println("Enter the accountId to whom you wanted to transfer");
		int acntRecp = obj.nextInt();
		System.out.println("Enter amount to Transfer");
		int transamnt = obj.nextInt();
		accnt = new Account();
		double abal = daoI.viewBalance(acnum);
		double bbal = daoI.viewBalance(acntRecp);
		if (transamnt < abal) {
			abal = abal - transamnt;
			bbal = bbal + transamnt;
			daoI.update(acnum, abal);
			daoI.update(acntRecp, bbal);
			System.out.println("transferd successfully");
			String str = "transferred";
			daoI.printDetails(acnum, acntRecp, transamnt, str);
		} else {
			System.out.println("Insuffient balance");
		}

	}

	public double viewBalance(int accid) {
		daoI = new DAOClass();
		double bal = daoI.viewBalance(accid);
		return bal;
	}

	public void printDetails() {

		daoI = new DAOClass();
		System.out.println(daoI.viewDetails());
	}

	@Override
	public int create(Account account) {

		return 0;
	}

	@Override
	public double update(int acntid, double balance) {

		return 0;
	}

	@Override
	public void printDetails(int aid, int acntid, int amnt, String s) {

	}

}
