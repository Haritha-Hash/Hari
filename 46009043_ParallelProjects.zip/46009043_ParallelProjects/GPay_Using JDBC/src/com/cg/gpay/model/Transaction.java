/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is transaction class
 */
package com.cg.gpay.model;

public class Transaction {
	private int accountId;
	private int accountId2;

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getAccountId2() {
		return accountId2;
	}

	public void setAccountId2(int accountId2) {
		this.accountId2 = accountId2;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	private int amount;
	private String message;

	@Override
	public String toString() {
		return "Transaction [accountId=" + accountId + ", accountId2=" + accountId2 + ", amount=" + amount
				+ ", message=" + message + "]";
	}
}
