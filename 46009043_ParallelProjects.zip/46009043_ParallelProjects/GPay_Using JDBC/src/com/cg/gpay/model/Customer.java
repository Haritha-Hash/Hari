/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is  customer  class
 */
package com.cg.gpay.model;

public class Customer {
	private int custId;
	private String custName;
	private Account account;
	private double bal;

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public double getBal() {
		return bal;
	}

	public void setBal(double bal) {
		this.bal = bal;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", account=" + account + ", bal=" + bal + "]";
	}

}
