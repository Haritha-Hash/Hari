/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is account class
 */
package com.cg.gpay.model;

public class Account {
	private double balance;
	private double amount;
	private String custName;
	private String phoneNo;
	private int accountId;
	private String accountType;
	private String city;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getAmount(double amount, double balance) {
		amount = balance + amount;
		return amount;
	}

	public void setAmount(int balance, double amount) {
		this.amount = amount;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Account [balance=" + balance + ", amount=" + amount + ", custName=" + custName + ", phoneNo=" + phoneNo
				+ ", accountId=" + accountId + ", accountType=" + accountType + ", city=" + city + "]";
	}

	public double withdraw(double amount1, double balance1) {
		amount1 = amount1 - balance1;

		return amount1;
	}

}
