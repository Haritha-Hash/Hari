/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is the class which connects with database
 */
package com.cg.gpay.helper;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	static Connection conn = null;

	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "India1234");
		} catch (ClassNotFoundException se) {

			se.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return conn;

	}

	public static void main(String args[]) {
		System.out.println(getConnection());
	}

}
