package com.cg.gpay.helper;
public interface QueryMapper{
public static final String INSERT_ACCOUNT = "insert into account values(?,?,?,?,?,?)";
public static final String INSERT_TRANSACTION_DETAILS = "insert into printdetails values(?,?,?,?)";
public static final String VIEW_TRANSACTION_DETAILS = "select * from printdetails";
public static final String VIEW_BALANCE="select BALANCE from ACCOUNT1 where ACCCOUNTID =";
public static final String CHECK_ACCOUNT_ID="select acccountId from account1";
public static final String VIEW_DETAILS="select * from printdetails where accountid=";
public static final String UPDATE_DETAILS="update account1 set balance = ? where acccountid =";


}
