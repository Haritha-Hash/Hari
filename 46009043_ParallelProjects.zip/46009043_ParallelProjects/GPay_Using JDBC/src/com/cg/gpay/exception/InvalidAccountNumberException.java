/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is invalid account number exception class
 */
package com.cg.gpay.exception;

public class InvalidAccountNumberException {
	public InvalidAccountNumberException() {
		super();

	}

	@Override
	public String toString() {
		return "InvalidAccountNumber";
	}

}
