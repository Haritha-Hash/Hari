/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is invalid mobile number exception class
 */
package com.cg.gpay.exception;

public class InvalidMobileNumberException {
	public InvalidMobileNumberException() {
		super();

	}

	@Override
	public String toString() {
		return "InvalidMobileNumberException";
	}

}
