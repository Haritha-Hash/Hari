/**
 * @author HABOLLIN
 * DATE 18/10/2019
 * 
 * This is invalid amount exception class
 */
package com.cg.gpay.exception;

public class InvalidAmountException {
	public InvalidAmountException() {
		super();

	}

	@Override
	public String toString() {
		return "Insufficient balance!!";
	}

}
