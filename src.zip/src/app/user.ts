export class User {
    public userId: number;
    public fname: string;
    public lname: string;
    public email: string;
    public password: string;
    public confirmpassword: string;
    public birthdate: string;
}
