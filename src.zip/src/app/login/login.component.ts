import { Component, OnInit } from '@angular/core';
import { CapbookService } from '../capbook.service';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  //userDetails: User;
  constructor(private capbookService:CapbookService,private router:Router) {
   // this.userDetails=new User();
   }

  ngOnInit() {
  }
   checkUsers(email,password){
  //this.userDetails.email=email;
  if(email=="" ){
     alert("Email Should Be filled")
    }
    else if( password==""){
      alert("Password Should Be filled")
    }
    else{

  this.capbookService.checkUsers(email,password).subscribe(data=>{
    if(data===true){
     this.router.navigate(['Profile'])
    }else{
    window.alert("You Are Not An Existing User...:(");}

  });
}}

}
