import { Component, OnInit } from '@angular/core';
import{CapbookService} from '../capbook.service'; 
import {FormBuilder, Validators } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  userDetails: User;

  constructor(private capbookService:CapbookService) {
    this.userDetails=new User();
  
   
  }

  ngOnInit() {
    
  }
  createUser(userId,fname,lname,email,password,confirmpassword,birthdate):void{
    this.userDetails.userId=userId;
    this.userDetails.fname=fname;
    this.userDetails.lname=lname;
    this.userDetails.email=email;
    this.userDetails.password=password;
    this.userDetails.confirmpassword=confirmpassword;
    this.userDetails.birthdate=birthdate;
    this.capbookService.createUser(this.userDetails).subscribe(data=>{
      alert("User added Successfully.");
    });
  }

}
