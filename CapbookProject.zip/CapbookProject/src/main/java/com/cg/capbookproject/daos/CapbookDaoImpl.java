package com.cg.capbookproject.daos;

public class CapbookDaoImpl {

}
