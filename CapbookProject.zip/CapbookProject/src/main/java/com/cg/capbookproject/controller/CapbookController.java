package com.cg.capbookproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capbookproject.beans.User;

import com.cg.capbookproject.exceptions.CapbookException;
import com.cg.capbookproject.services.ICapbookService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CapbookController {
	@Autowired
	ICapbookService userService;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public User addDetails(@RequestBody User user) {
		return userService.addDetails(user);
	}

	@RequestMapping(value = "/getusers", method = RequestMethod.GET)
	public List<User> getDetails(@RequestBody User user) {
		return userService.getDetails();
	}

	/*@RequestMapping(value = "/update/{email}/{password}/{confirmPassword}", method = RequestMethod.PUT) // updating the fields
	public boolean updateDetails( @RequestBody User user,@PathVariable String password,@PathVariable String confirmPassword) {
	
			return userService.updatePassword(user,password,confirmPassword);
			 
	}*/

	@RequestMapping(value = "/delete/{userId}", method = RequestMethod.DELETE) // Delete by Id
	public void deletedetail(@PathVariable int userId) throws CapbookException {
		userService.deleteDetails(userId);
	}

	@RequestMapping(value = "/getusers/{userId}", method = RequestMethod.GET) // finding by single USER
	public User findSingleUser(@PathVariable int userId) throws CapbookException  {
		return userService.findSingleUser(userId);
	}
	@RequestMapping(value = "/checkusers/{email}/{password}", method = RequestMethod.GET) // finding by single USER
	public boolean checkUser(@PathVariable String email,@PathVariable String password){
		return userService.checkUser(email,password);
	}
	@RequestMapping(value = "/verifyemail/{email}", method = RequestMethod.GET) // finding by single USER
	public boolean verifyEmail(@PathVariable String email)throws CapbookException {
		return userService.verifyEmail(email);
	}
	@PutMapping("/{email}/{password}/{confirmPassword}")
	public void forgotPassword(@PathVariable String email,@RequestBody User user,@PathVariable String password,@PathVariable String confirmPassword)
	{
		userService.forgotPassword(email, user, password,confirmPassword);
		
	}


}