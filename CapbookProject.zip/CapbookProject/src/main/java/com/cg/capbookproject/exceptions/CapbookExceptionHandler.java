package com.cg.capbookproject.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CapbookExceptionHandler {
@ExceptionHandler(CapbookException.class)
	 public ResponseEntity <String> handleException(Exception ex){
			return new ResponseEntity <String> ("Error Occured",HttpStatus.NOT_FOUND);
			
		}

}
