import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ForgetpasswordComponent } from './ForgetPassword/forgetpassword.component';
import { SignupComponent } from './signup/signup.component';
import { ChangepasswordComponent } from './ChangePassword/changepassword.component';

import { ProfileimageComponent } from './Profile/profileimage.component';
import { ProfilepageComponent } from './profilepage/profilepage.component';
import { VerifyComponent } from './verify/verify.component';

const routes: Routes = [
  { path:'' ,component:LoginComponent},
  {path:'\ForgetPassword',component:ForgetpasswordComponent},
  {path:'\Verify',component:VerifyComponent},
  { path:'\signup',component:SignupComponent},
  {path:'\ChangePassword',component:ChangepasswordComponent},
  {path:'\Profile',component:ProfilepageComponent},
  {path:'\profileimage',component:ProfileimageComponent},
  {path:'\login',component:LoginComponent},

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
