import { Component, OnInit, Output } from '@angular/core';
import { CapbookService } from '../capbook.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
  //@Output() email: string
  userDetails: User;

  constructor(private capbookService:CapbookService,private router:Router) { 
    this.userDetails=new User();
  }

  ngOnInit() {
  }



  changePassword(userId,fname,lname,email,password,confirmpassword,birthdate):void{
    
    this.capbookService.changepassword(email,password,confirmpassword).subscribe(data=>{
      if(data===true){
        window.alert("Your Password Changed Successfully");
        this.userDetails.userId=userId;
        this.userDetails.fname=fname;
        this.userDetails.lname=lname;
        this.userDetails.email=email;
        this.userDetails.email=email;
        this.userDetails.password=password;
        this.userDetails.confirmpassword=confirmpassword;
        this.userDetails.birthdate=birthdate;
      }else{
      window.alert("You Have Entered An Invalid Mail Id");}
  
    });

}}
