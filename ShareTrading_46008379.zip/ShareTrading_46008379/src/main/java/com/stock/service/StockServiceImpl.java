package com.stock.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.beans.Stock;
import com.stock.dao.StockRepository;
import com.stock.exception.StockException;

@Service //service implementation of the service class
public class StockServiceImpl implements StockService {
	
	@Autowired
	private StockRepository stockRepo;

	@Override //creating stocks
	public List<Stock> createStock(Stock stock) throws StockException {
		if(stockRepo.existsById(stock.getId())) {
			throw new StockException();
		}
		stock=calculateOrder(stock);
		stockRepo.save(stock);
		return viewAllStock();
	}
	// calculating the trading amount
	public Stock calculateOrder(Stock stock) { 
		
		int quantity=stock.getQuantity();
		double price=stock.getPrice();
		double tradingAmount=price*quantity;
		double brokerage;
		if(quantity>100)
		{
			brokerage=(tradingAmount*(0.3))/100;
		}
		else
		{
			brokerage=(tradingAmount*(0.5)/100);
		}
		stock.setAmount(tradingAmount);
		stock.setBrokerage(brokerage);
		return stock;
		
	}

	/*@Override //updating the stock
	public List<Stock> updateStock(int id ,Stock stock) throws StockException {
		if(!stockRepo.existsById(stock.getId())) {
			throw new StockException("Stock Id with " + stock.getId() + " Does not Exist");
		}
		Stock s = stockRepo.findById(stock.getId()).get();
		s.setPrice(stock.getPrice());
		s.setQuantity(stock.getQuantity());
		s=calculateOrder(s);
		stockRepo.save(s);
		return viewAllStock();
	}*/
	//@Override
    public List<Stock> updateStock(int id,Stock stock) throws StockException{
       
        try {
        Optional<Stock> optional=stockRepo.findById(id);
        if(optional.isPresent())
        {
            Stock product=optional.get();
            product.setName(stock.getName());
           
            product.setPrice(stock.getPrice());
            product.setQuantity(stock.getQuantity());
            product.setAmount(stock.getAmount());
            product.setBrokerage(stock.getBrokerage());
            stockRepo.save(product);
            return viewAllStock();
        }else {
            throw new StockException("Product with the Id"+id+" is not present please enter a valid one ");   
        }
    }
    catch(Exception ex) {
        throw new StockException(ex.getMessage());
    }
       
    }

	@Override //deleting the stock
	public List<Stock> deleteStock(int id) throws StockException {
		if(!stockRepo.existsById(id)) {
			throw new StockException("Stock Id with " + id + " Does not Exist");
		}
		stockRepo.deleteById(id);
		return viewAllStock();
	}

	@Override //view all stocks
	public List<Stock> viewAllStock() throws StockException {
		try {
			return stockRepo.findAll();
		} catch (Exception e) {
			throw new StockException(e.getMessage());
		}
	}

	@Override //finding by single stock
	public Stock findSingleStock(int id) throws StockException {
		if(!stockRepo.existsById(id)) {
			throw new StockException("Stock Id with " + id + " Does not Exist");
		}
		return stockRepo.findById(id).get();
	}

}
