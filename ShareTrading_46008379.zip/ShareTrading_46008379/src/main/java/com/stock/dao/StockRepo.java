package com.stock.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.stock.beans.Stock;



@Repository
public class StockRepo {

	@PersistenceContext
	private EntityManager entityManager;

	{
		System.out.println("entityManager" + entityManager);
	}

	public List<Stock> list() {
		Query query = entityManager.createQuery("from Stock");
		return query.getResultList();
	}

	public int saveOrder(Stock bean) {
    entityManager.persist(bean);
		System.out.println("entityManager" + entityManager);
		return 0;

	}

}

