package com.cg.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageP {
	@FindBy(xpath="//*[@id=\"desktop-header-cnt\"]/div[2]/div[2]/div/div[1]/span[2]")
    WebElement profile;
	@FindBy(xpath="//*[@id=\"desktop-header-cnt\"]/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[1]/a[2]")
	WebElement login;
	@FindBy(xpath="//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[1]/input")
	WebElement email;
	@FindBy(xpath="//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[2]/input")
	WebElement password;
	@FindBy(xpath="//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[2]/button")
	WebElement submit;
	
	public PageP(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	

public void clickProfile() {
	profile.click();
}

public void clickLogin() {
	login.click();
}
public void enterCredentials() {
	email.sendKeys("harrypotter@gmail.com");
	password.sendKeys("harry@1");
}
public void submit() {
	submit.click();
}
}










