package com.cg.stepdef;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPage {
	
	WebDriver driver;
	 Actions action;
	 ChromeOptions options;
	 PageP login;
	@Given("^user is on Myntra Login page$")
	public void user_is_on_Myntra_Login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver","C:\\Users\\MB12\\chromedriver.exe");
		options= new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver=new ChromeDriver();
		driver.get("https://www.myntra.com");
	    action=new Actions(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	   // WebElement profile=driver.findElement(By.xpath("//*[@id=\"desktop-header-cnt\"]/div[2]/div[2]/div/div[1]/span[2]"));
	//	 action.moveToElement(profile).build().perform();
	//	 driver.findElement(By.xpath("//*[@id=\"desktop-header-cnt\"]/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[1]/a[2]")).click();
 		  login =new PageP(driver);
 		 login.clickProfile();
 		 login.clickLogin();
 		 
 		
		
	  //  throw new PendingException();
	}

	@When("^user enters username and password$")
	public void user_enters_username_and_password(DataTable arg1) throws Throwable {
	  /*  // Write code here that turns the phrase above into concrete actions
		List<List<String>>list=arg1.raw();
		WebElement userName=driver.findElement(By.name("email"));
		userName.sendKeys(list.get(0).get(0));///instead of wbelement can use driver.xpath().sendkeys()arg1;
		WebElement password=driver.findElement(By.name("password"));
		password.sendKeys(list.get(0).get(1));
		//password.submit();
	    //throw new PendingException();*/
		login.enterCredentials();
	}

	@When("^user clicks on submit$")
	public void user_clicks_on_submit() throws Throwable {
	    
	//	driver.findElement(By.xpath("//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[2]/button")).click();;
	  //  throw new PendingException();
		 login.submit();
	}

	@Then("^Home page must appear$")
	public void home_page_must_appear() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		Assert.assertEquals("Login",driver.getTitle());
	   // throw new PendingException();
	}

}
