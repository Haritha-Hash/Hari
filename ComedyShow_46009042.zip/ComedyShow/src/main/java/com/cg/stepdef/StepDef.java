package com.cg.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDef {
	
	WebDriver driver;
	Actions action;
	ChromeOptions options;
	MainPage enter;
	
	@Given("^user is on comedy show management system application$")
	public void user_is_on_comedy_show_management_system_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\MB12\\chromedriver.exe");
		options= new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver=new ChromeDriver();
		driver.get("C:\\Users\\MB12\\Music\\ComedyShow.html");
		enter=new MainPage(driver);
	}

	@When("^user does not enter ComedyShowiId$")
	public void user_does_not_enter_ComedyShowiId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		enter.ComedyShowID("");
		enter.ComedyShowTitle("joker");
		enter.ReleaseDate("12/3/2019");
		enter.Comedian("charlie");
		enter.ComedyShowDuration("two hours");
		enter.Language("Hindi");
		enter.ComedyShowRating("3");
		enter.AddComedyShow("");
	}

	@Then("^ComdeyShowId must be filled out$")
	public void comdeyshowid_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		String expectedMessage="ComedyShow ID must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter ComedyShowTitle$")
	public void user_does_not_enter_ComedyShowTitle() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		enter.ComedyShowTitle("");
		enter.AddComedyShow("");
	}

	@Then("^ComdeyShowTitle must be filled out$")
	public void comdeyshowtitle_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		String expectedMessage="ComedyShow Title field must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter ReleaseDate$")
	public void user_does_not_enter_ReleaseDate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		enter.ReleaseDate("");
		enter.AddComedyShow("");
	}

	@Then("^ReleaseDate must be filled out$")
	public void releasedate_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		String expectedMessage="Release Date field must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter Comedian$")
	public void user_does_not_enter_Comedian() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		enter.Comedian("");
		enter.AddComedyShow("");
	}

	@Then("^Comedian must be filled out$")
	public void comedian_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		String expectedMessage="ComedyShow Comedian  must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter ComedyShowDuration$")
	public void user_does_not_enter_ComedyShowDuration() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		enter.ComedyShowDuration("");
		enter.AddComedyShow("");
	}

	@Then("^ComdeyShowDuration must be filled out$")
	public void comdeyshowduration_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		String expectedMessage="ComedyShow Duration must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter Language$")
	public void user_does_not_enter_Language() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		enter.Language("");
	enter.AddComedyShow("");
	}

	@Then("^Language must be filled out$")
	public void language_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		String expectedMessage="ComedyShow Language must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter ComedyShowRating$")
	public void user_does_not_enter_ComedyShowRating() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		enter.ComedyShowRating("");
	    enter.AddComedyShow("");
	}

	@Then("^ComdeyShowRating must be filled out$")
	public void comdeyshowrating_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		String expectedMessage="ComedyShow rating must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters required details$")
	public void user_enters_required_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		enter.ComedyShowID("");
		enter.ComedyShowTitle("");
		enter.ReleaseDate("");
		enter.Comedian("");
		enter.ComedyShowDuration("");
		enter.Language("");
		enter.ComedyShowRating("");
		
	}

	@When("^user clicks on add comedy show$")
	public void user_clicks_on_add_comedy_show() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		enter.AddComedyShow("");
	}

	@Then("^Comedy show added succesfully must appear$")
	public void comedy_show_added_succesfully_must_appear() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		String expectedMessage="ComedyShow added successfully";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}


	
}
