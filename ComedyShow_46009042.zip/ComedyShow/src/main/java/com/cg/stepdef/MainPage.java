package com.cg.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MainPage {

@FindBy(xpath="//*[@id=\"Text24\"]")
WebElement ComedyShowID;
@FindBy(xpath="//*[@id=\"Text1\"]")
WebElement ComedyShowTitle;
@FindBy(xpath="//*[@id=\"Text12\"]")
WebElement ReleaseDate;
@FindBy(xpath="//*[@id=\"Text14\"]")
WebElement Comedian;
@FindBy(xpath="//*[@id=\"Text15\"]")
WebElement ComedyShowDuration;
@FindBy(xpath="//*[@id=\"Select12\"]")
WebElement Language;
@FindBy(xpath="//*[@id=\"Select9\"]")
WebElement ComedyShowRating;
@FindBy(xpath="//*[@id=\"Button4\"]")
WebElement AddComedyShow;

public MainPage(WebDriver driver) {
	PageFactory.initElements(driver, this);
}

public void ComedyShowID(String string) {
	// TODO Auto-generated method stub
	ComedyShowID.sendKeys("12");
}

public void ComedyShowTitle(String string) {
	// TODO Auto-generated method stub
	ComedyShowTitle.sendKeys("joker");
}

public void ReleaseDate(String string) {
	// TODO Auto-generated method stub
	ReleaseDate.sendKeys("12/2/2019");
}

public void Comedian(String string) {
	// TODO Auto-generated method stub
	Comedian.sendKeys("Charlie");
}

public void ComedyShowDuration(String string) {
	// TODO Auto-generated method stub
	ComedyShowDuration.sendKeys("two hours");
}

public void Language(String string) {
	// TODO Auto-generated method stub
	Language.sendKeys("Hindi");
}

public void ComedyShowRating(String string) {
	// TODO Auto-generated method stub
	ComedyShowRating.sendKeys("3");
}
public void AddComedyShow(String string) {
	// TODO Auto-generated method stub
	AddComedyShow.click();
}







}
