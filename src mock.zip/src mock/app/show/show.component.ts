import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
employee;
  constructor(private emp:EmployeeService) { 
    emp.getAll().subscribe((res) => this.employee=res)
  }
  removeEmployee(id){
    this.emp.remove(id).subscribe(()=>{
    alert('deleted...')
    history.go(); 
    })
   }
  ngOnInit() {
  }

}
