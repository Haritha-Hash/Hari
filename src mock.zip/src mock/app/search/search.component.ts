import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  search;
  b;
  book;
  constructor(private e:EmployeeService, private router:Router) { }
  searchProduct(search)
  {
  this.b=search
  this.e.getAll().subscribe((res)=>this.book=res)
 
  
   
  }
  ngOnInit() {
  }

}
