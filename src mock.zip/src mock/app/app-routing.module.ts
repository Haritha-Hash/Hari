import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';
import { ShowComponent } from './show/show.component';
import { DeleteComponent } from './delete/delete.component';
import { SearchComponent } from './search/search.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  { path:'',component:HomeComponent},
  
  {path:'add', component:AddComponent},
  {path:'show', component:ShowComponent},
  {path:'delete', component:DeleteComponent},
  {path:'search', component:SearchComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
