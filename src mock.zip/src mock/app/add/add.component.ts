import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private emp:EmployeeService, private router:Router) { }
  employee={
    "empid":'',
    "empname":'',
    "projectname":'',
    "managername":''
  }
  addEmployee(){
    this.emp.add(this.employee).subscribe(()=> {
     alert('addedd...')
    this.router.navigate(['show'])
     }
     )
     }
  ngOnInit() {
  }

}
