import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(private emp:EmployeeService) { }
  delEmp(delId){
    
    this.emp.remove(delId).subscribe(()=>{
    alert('deleted...')
    history.go(); 
    })
   }

  ngOnInit() {
  }

}
