package com.cg.TripReviewManagement_46009043.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.TripReviewManagement_46009043.pojo.Reviews;

@Repository
public class ReviewRepoImpl {

}
