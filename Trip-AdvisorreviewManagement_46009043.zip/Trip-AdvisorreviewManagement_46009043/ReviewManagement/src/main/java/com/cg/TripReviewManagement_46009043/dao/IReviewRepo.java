package com.cg.TripReviewManagement_46009043.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.TripReviewManagement_46009043.pojo.Reviews;


@Repository
public interface IReviewRepo  extends JpaRepository<Reviews,Long> {
	

}
