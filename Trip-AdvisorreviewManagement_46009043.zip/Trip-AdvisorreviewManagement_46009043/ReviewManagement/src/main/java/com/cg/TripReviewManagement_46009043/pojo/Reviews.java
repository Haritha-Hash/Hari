package com.cg.TripReviewManagement_46009043.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table

public class Reviews {

	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	@OneToMany(cascade = CascadeType.ALL)
	private List<Reviewer> reviewer = new ArrayList<>();

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	Long reviewId;
	
	
	@Column
	String description;
	
	@Column
	int rating;
	@Column
	Long references;
	@OneToMany
	@Column
	int reviewerId;

	public Reviews() {
	}

	public Long getReviewId() {
		return reviewId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getReferences() {
		return references;
	}

	public void setReferences(Long references) {
		this.references = references;
	}

	public int getReviewerId() {
		return reviewerId;
	}

	public void setReviewerId(int reviewerId) {
		this.reviewerId = reviewerId;
	}

}
