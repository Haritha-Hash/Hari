package com.cg.TripReviewManagement_46009043.ServiceLayer;

public interface IReviewService {

}
