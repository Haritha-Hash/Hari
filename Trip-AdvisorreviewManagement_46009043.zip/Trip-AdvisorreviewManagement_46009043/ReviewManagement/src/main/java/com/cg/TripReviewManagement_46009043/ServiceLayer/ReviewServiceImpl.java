package com.cg.TripReviewManagement_46009043.ServiceLayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.TripReviewManagement_46009043.pojo.Reviews;

public class ReviewServiceImpl {
	private static Map<Long, Reviews> reviews = new HashMap<Long, Reviews>();
	private static Long idIndex = 3L;

	@Autowired

	public List<Reviews> getAll() {
		return new ArrayList<Reviews>(reviews.values());
	}

	public static Reviews create(Reviews review) {
		idIndex += idIndex;

		
		reviews.put(idIndex, review);
		return review;
	}

	public static Reviews get(Long reviewId) {
		return reviews.get(reviewId);
	}

	public static Reviews update(Long reviewId, Reviews review) {
		reviews.put(reviewId, review);
		return review;
	}

	public static Reviews delete(Long reviewId) {
		return reviews.remove(reviewId);
	}
}
