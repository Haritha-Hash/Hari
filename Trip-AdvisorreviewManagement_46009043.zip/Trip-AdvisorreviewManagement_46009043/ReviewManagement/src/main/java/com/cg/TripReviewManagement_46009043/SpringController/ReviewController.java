package com.cg.TripReviewManagement_46009043.SpringController;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.TripReviewManagement_46009043.dao.IReviewRepo;
import com.cg.TripReviewManagement_46009043.pojo.Reviews;

@RestController
@RequestMapping("api/v1")
public class ReviewController {

	@Autowired
	private IReviewRepo repository;

	@RequestMapping(method = RequestMethod.GET, value = "reviews")
	List<Reviews> list() {
		System.out.println("inside list() method call");
		return repository.findAll();
	}

	@RequestMapping(method = RequestMethod.POST, value = "reviews")
	public void addReviews(@RequestBody Reviews review) {
		repository.save(review);
	}

	@RequestMapping(method = RequestMethod.GET, value = "reviews/{reviewId}")
	public Reviews get(@PathVariable("reviewId") long reviewId) {
		Optional<Reviews> optional = repository.findById(reviewId);
		return optional.get();
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "reviews/{reviewId}")
	public ResponseEntity<?> delete(@PathVariable("reviewId") long reviewId) {
		Optional<Reviews> optionalReview = repository.findById(reviewId);
		repository.delete(optionalReview.get());
		return ResponseEntity.ok().build();
	}

	@RequestMapping(method = RequestMethod.PUT, value = "updatereview/{reviewId}")
	public Reviews update(@PathVariable(value = "reviewId") long reviewId, @RequestBody Reviews review) {
		Optional<Reviews> optionalReview = repository.findById(reviewId);
		Reviews existingReview = optionalReview.get();
		BeanUtils.copyProperties(review, existingReview);
		repository.saveAndFlush(existingReview);
		return repository.save(review);
	}

}
