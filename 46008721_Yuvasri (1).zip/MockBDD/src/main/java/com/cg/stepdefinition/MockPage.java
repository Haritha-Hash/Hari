package com.cg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class MockPage {
	
	WebElement pageTitle;
	
	@FindBy(xpath="//*[@id=\'Text24\']")
	WebElement showId;
	
	@FindBy(xpath="//*[@id=\'Text1\']")
	WebElement showTitle;
	
	@FindBy(xpath="//*[@id=\'Text12\']")
	WebElement releaseDate;
	
	@FindBy(xpath="//*[@id=\'Text14\']")
	WebElement comedianName;
	
	@FindBy(xpath="//*[@id=\'Text15\']")
	WebElement showDuration;
	
	@FindBy(xpath="//*[@id=\'Select12\']")
	WebElement showLanguage;
	
	@FindBy(xpath="//*[@id=\'Select9\']")
	WebElement showRating;	
	
	@FindBy(xpath="//*[@id=\'Button4\']")
	WebElement submitBtn;
	
	@FindBy(xpath="//*[@id=\'Button5\']")
	WebElement cancelBtn;
	
	WebDriver driver;
	
	
	public MockPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void enterShowId() {
		showId.sendKeys("10");
	}
	
	public void enterShowTitle() {
		showTitle.sendKeys("Jabardasth");
	}
	
	public void enterReleaseDate() {
		releaseDate.sendKeys("10/02/2017");
	}
	
	public void enterComedianName() {
		comedianName.sendKeys("Lavanya");
	}
	
	public void enterShowDuration() {
		showDuration.sendKeys("2:00");
	}
	
	public void enterLaguage() {
		Select lang = new Select(showLanguage);
        lang.selectByValue("13");
	}
	
	public void enterRating() {
		Select lang = new Select(showRating);
        lang.selectByValue("5");
	}
	
	public void NoenterShowId() {
		showId.sendKeys("");
	}
	
	public void NoenterShowTitle() {
		showTitle.sendKeys("");
	}
	
	public void NoenterReleaseDate() {
		releaseDate.sendKeys("");
	}
	
	public void NoenterComedianName() {
		comedianName.sendKeys("");
	}
	
	public void NoenterShowDuration() {
		showDuration.sendKeys("");
	}
	
	public void NoenterLaguage() {
		Select lang = new Select(showLanguage);
        lang.selectByValue("");
	}
	
	public void NoenterRating() {
		Select lang = new Select(showRating);
        lang.selectByValue("");
	}
	
	public void clickSubmit() {
		submitBtn.click();
	}	
}
