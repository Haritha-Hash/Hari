import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { UserAccount } from '../UserInterface/user-account';
@Component({
  selector: 'app-deleteaccount',
  templateUrl: './deleteaccount.component.html',
  styleUrls: ['./deleteaccount.component.css']
})
export class DeleteaccountComponent implements OnInit {
  emailID: string;
  message:string;
  userAccountDetails:UserAccount;
  _password:string;
  errorMessage:string;
  constructor(public router: Router,public userAccountService:UseraccountService) { }

  get password():string{
    return this._password;
  } 
  set password(value: string){
    this._password = value;
  }
  ngOnInit() {
    this.emailID = localStorage.getItem('token');
    console.log(this.emailID);
    this.userAccountService.getUserAccountDetails(this.emailID).subscribe (
      userAccountDetails=>{
      this.userAccountDetails=userAccountDetails;
      this.emailID=userAccountDetails.emailID;
      
      console.log(this.userAccountDetails.password);
      }
      ,
      errorMessage=>{
        this.message="Email ID does not exist.";
      });
  }

  back(): void {
    console.log("back");
    this.router.navigate(['/timelineComponent']);
  }
  delete(): void {
      if(this._password==this.userAccountDetails.password){
        this.userAccountService.deleteUserAccountDetails(this.emailID).subscribe(
          x=>{
            console.log("x");
            
          },
          y=>{
            console.log("y");
            this.router.navigate(['/welcomeComponent']);
          }

  );
  }
  else{
    this.message="Please check your password"
  }
}
}
