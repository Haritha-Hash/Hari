import { UserAccount } from '../UserInterface/user-account';
export interface NotificationInterface {
    notoficatonMessage:string;
    senderEmailID:string;
    userAccount:UserAccount
}
