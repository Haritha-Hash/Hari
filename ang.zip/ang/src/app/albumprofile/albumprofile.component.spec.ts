import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlbumprofileComponent } from './albumprofile.component';

describe('AlbumprofileComponent', () => {
  let component: AlbumprofileComponent;
  let fixture: ComponentFixture<AlbumprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlbumprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlbumprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
