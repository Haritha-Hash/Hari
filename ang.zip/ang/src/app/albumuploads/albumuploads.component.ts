import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { PhotoInterface } from '../AllInterFace/photo-interface';
@Component({
  selector: 'app-albumuploads',
  templateUrl: './albumuploads.component.html',
  styleUrls: ['./albumuploads.component.css']
})
export class AlbumuploadsComponent implements OnInit {
  emailID: string;
  allImageForUpdate:PhotoInterface[];
  errorUpdateImage:string;
  constructor(private router: Router,public userAccountService:UseraccountService) { }
  ngOnInit() {
    this.emailID = localStorage.getItem('token');
    this.userAccountService.getAllImageForUpdate(this.emailID).subscribe(
      x => {
        this.allImageForUpdate=x;
      }
      ,
      y=>{
        this.errorUpdateImage=y;
      }
     );
  }
  back(): void {
    this.router.navigate(['/photosComponent']);
  }
}
