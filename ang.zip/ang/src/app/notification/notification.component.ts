import { Component, OnInit } from '@angular/core';
import { UseraccountService } from '../Services/useraccount.service';
import { NotificationInterface } from '../AllInterFace/notification-interface';
import { Router } from '@angular/router';
@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {
  emailID:string;
  allNotification:NotificationInterface[];
  constructor(private userAccountService:UseraccountService,private router:Router) { }
  ngOnInit() {
    this.emailID=localStorage.getItem('token');
    this.userAccountService.getNotification(this.emailID).subscribe(
      x=>{
        this.allNotification=x
      },
      y=>{   
      }
    );
  }
  back(): void {  
    this.router.navigate(['/homepageComponent']);
  }
}
