import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { UserAccount } from '../UserInterface/user-account';

@Component({
  selector: 'app-frienddetails',
  templateUrl: './frienddetails.component.html',
  styleUrls: ['./frienddetails.component.css']
})
export class FrienddetailsComponent implements OnInit {
  friendEmailID: string;
  friendAccountDetails: UserAccount;
  constructor(private router: Router,private userAccountService: UseraccountService) { }

  ngOnInit() {
    this.friendEmailID = localStorage.getItem('token1');
    this.userAccountService.getUserAccountDetails(this.friendEmailID).subscribe(
      x=>{
        this.friendAccountDetails=x;
      },
      y=>{ 
      }
    );
  }
  back(): void {
    this.router.navigate(['/friendprofileComponent']);
  }

}
