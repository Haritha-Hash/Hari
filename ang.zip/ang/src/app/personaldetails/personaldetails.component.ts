import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { UserAccount } from '../UserInterface/user-account';
@Component({
  selector: 'app-personaldetails',
  templateUrl: './personaldetails.component.html',
  styleUrls: ['./personaldetails.component.css']
})
export class PersonaldetailsComponent implements OnInit {
  emailID: string;
  message:string;
  userAccountDetails:UserAccount;
  school: string;
  college: string;
  religion: string;
  relationshipStatus: string;
  homeTown: string;
  currentCity: string;
  phoneNumber: string;
  company: string;
  constructor(private router: Router,public userAccountService:UseraccountService) { }
  ngOnInit() {
    this.emailID = localStorage.getItem('token');
  this.userAccountService.getUserAccountDetails(this.emailID).subscribe (
      userAccountDetails=>{
      this.userAccountDetails=userAccountDetails; 
    },
    errorMessage=>{
      this.message="Email ID does not exist.";
    }
  );
  }
  saveDetails(){
    this.userAccountService.acceptExtraUserDetails(this.emailID,this.school,this.college,this.religion,this.relationshipStatus,this.homeTown,this.currentCity,this.phoneNumber,this.company).subscribe(
      message=>{
        this.message="Details Saved";
      },
        errorMessage=>{
        this.message=errorMessage;
        }
    );
  }
  back(): void {
    this.router.navigate(['/timelineComponent']);
  }
  edit(): void {
    this.router.navigate(['/editprofileComponent']);
  }
}
