package com.cg.service;

import com.cg.bean.Client;
import com.cg.exception.QuestionException;

public interface IQuestionService {
	public Client addQuestion(Client client);
}
