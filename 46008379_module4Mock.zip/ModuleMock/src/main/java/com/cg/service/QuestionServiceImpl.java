package com.cg.service;



import org.springframework.stereotype.Service;

import com.cg.bean.Client;
import com.cg.dao.IQuestionDAO;
import com.cg.exception.QuestionException;

import org.springframework.beans.factory.annotation.Autowired;

@Service
public class QuestionServiceImpl implements IQuestionService
{
@Autowired
IQuestionDAO quesDao;

@Override
public Client addQuestion(Client client) {
	
		 return	quesDao.save(client); 


}
}