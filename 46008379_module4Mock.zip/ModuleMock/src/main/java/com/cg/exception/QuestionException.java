package com.cg.exception;

public class QuestionException extends Exception{
	
	
	public QuestionException(String s) {
		super(s);
	}

}
