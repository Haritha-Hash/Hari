package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Client;
import com.cg.exception.QuestionException;
import com.cg.service.IQuestionService;

@RestController
public class QuestionController {
	@Autowired
	IQuestionService quesService;

	@RequestMapping(value = "/ques/add", method = RequestMethod.POST)
	public Client addBankAccount(@RequestBody Client client)  {

		return quesService.addQuestion(client);

}
}